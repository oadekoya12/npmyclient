---
edit_url: https://github.com/drush-ops/drush/blob/10.x/examples/Commands/ArtCommands.php
---

```php
--8<-- "examples/Commands/ArtCommands.php"
```
