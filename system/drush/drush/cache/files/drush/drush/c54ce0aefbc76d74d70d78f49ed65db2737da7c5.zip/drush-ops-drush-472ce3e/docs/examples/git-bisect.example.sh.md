---
edit_url: https://github.com/drush-ops/drush/blob/10.x/examples/git-bisect.example.sh
---
```shell
--8<-- "examples/git-bisect.example.sh"
```
