---
edit_url: https://github.com/drush-ops/drush/blob/10.x/examples/example.prompt.sh
---
```shell
--8<-- "examples/example.prompt.sh"
```
